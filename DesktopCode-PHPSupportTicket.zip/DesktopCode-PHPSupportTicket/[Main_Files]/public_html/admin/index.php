<?php session_start();
//error_reporting(0);
include('../user/include/config.php');
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
if(isset($_POST['submit']))
{
	$username=$_POST['username'];
	$password=md5($_POST['password']);
$ret=mysqli_query($con,"SELECT * FROM admin WHERE username='$username' and password='$password'");
$num=mysqli_fetch_array($ret);
if($num>0)
{
$_SESSION['alogin']=$_POST['username'];
$_SESSION['aid']=$num['id'];
header("location:dashboard.php");
}else{
echo "<script>alert('Invalid username or password');</script>";
//header("location:index.php");
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin Panel - PHP Support Ticket</title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="stylesheet" href="assets/css/style.css">
 <!-- Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
<style>
html *
{
font-family:<?php echo $rowfont['FontName'];?>;
}
</style>
</head>

  <!--header section start -->
   <div class="header_section">
      <div class="container-fluid ">
         <div class="row">
            <div class="col-sm-2 col-6">
            </div>
            <div class="col-sm-8 col-6">
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                     aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                  </button><font size="3">
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav">
                        <li class="nav-item">
                           <a class="nav-link" href="../index.php">Home</a>
                        </li>
                        <li class="nav-item active">
                           <a class="nav-link" href="index.php">Admin</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../user/index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../user/registration.php">User Regsitration</a>
                        </li>
                       
                        
                     </ul>
                  </div>
</font>
               </nav>
            </div>
         
         </div>
      </div>
<div class="auth-wrapper">
	<div class="auth-content text-center">
		<h4><span style="color:#000;"> Admin Login</span></h4>
		<hr />
		<div class="card borderless"  style="border: 1px solid black;">
			<div class="row align-items-center ">
				<div class="col-md-12">
					<form method="post">
					<div class="card-body">
					
						<div class="form-group mb-3">
							<input class="form-control" id="username" name="username" type="text" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Username" required />
						</div>
						<div class="form-group mb-4">
							<input class="form-control" id="password" name="password" type="password" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Password" required />
						</div>
						
						<button class="btn btn-block btn-primary mb-4"  type="submit" name="submit" style="border:1px solid black;border-radius:5px;color:black;"><font size="4">Signin</font></button>
						<hr>
					
					</div></form>
					  <i class="fa fa-home" aria-hidden="true"><a class="" href="../index.php">
		                 <font size="4">   Back Home</font>
		                </a></i>
				</div>
				
			</div>
		</div>
	</div>
</div>
</div></div></div></div></div>
<!-- [ auth-signin ] end -->
<div class="copyright_section">
      <div class="container">
         <br><br><center><p class="copyright_text"><font size="2">Copyright © 2025 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></font></p></center>
      </div>
   </div>

<!-- Required Js -->
<script src="assets/js/vendor-all.min.js"></script>
<script src="assets/js/plugins/bootstrap.min.js"></script>

<script src="assets/js/pcoded.min.js"></script>



</body>

</html>
