<?php
session_start();
include('../user/include/config.php');
if(strlen($_SESSION['aid'])==0)
    {   
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () );

if(isset($_POST['submit']))
{
    $state=$_POST['state'];
$sql=mysqli_query($con,"insert into tblfonts(FontName,FontURL) values('$state','$fonturl')");
$_SESSION['msg']="Font Added Successfully!";

}

if(isset($_GET['del']))
          {
                  mysqli_query($con,"delete from tblfonts where id = '".$_GET['id']."'");
                  $_SESSION['delmsg']="Font Deleted!";
          }


if($_GET['action']=='activated' && $_GET['id'])
{
	$id=intval($_GET['id']);
	$query=mysqli_query($con,"update tblfonts set website='0'");
                  $query=mysqli_query($con,"update tblfonts set website='1' where id='$id'");
	$msg="This Font Has Been Activated!";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>Admin Panel - PHP Support Ticket</title>
   

    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    

</head>
<body class="">
	<?php include('include/sidebar.php');?>
	<!-- [ navigation menu ] end -->
	<!-- [ Header ] start -->
	<?php include('include/header.php');?>

<!-- [ Main Content ] start -->
<section class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Font</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="site-fonts.php">Fonts</a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
          
            <!-- [ form-element ] start -->
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Fonts</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-10">
                            	<?php if(isset($_POST['submit']))
{?>
                                    <div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>Well done! <?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></strong>
                                    </div>
<?php } ?>


                                    <?php if(isset($_GET['del']))
{?>
<div class="alert alert-danger" role="alert">
                                    <strong><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?></strong>
                                    </div>
<?php } ?>

<?php if($msg){ ?>
<div class="alert alert-success alert-dismissible" role="alert">
<center><strong><?php echo htmlentities($msg);?></strong></center>
<button type="button" class="btn-close btn-close-black" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>

                                    <br />
                                <form method="post" name="Category">
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">Font Name</label>
                                       <input type="text" placeholder="Enter Font Name ( Montserrat )"  name="state" class="form-control" required>
                                    </div>   
                                    <div class="form-group">
                                       <label for="exampleInputEmail1">Font URL</label>
                                       <input type="text" placeholder="Enter Font URL //fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"."  name="fonturl" class="form-control" required>
                                    </div>   
                                    <button type="submit" class="btn  btn-primary" name="submit">Add</button>
                                </form>
                            </div>
                           
                        </div>
                     <hr>
                      <div class="row">
                            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Manage Fonts</h5>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                            <th>#</th>
                                            <th>Font Name</th>
                                            <th>Font URL</th>
 <th>Active</th>
                                            <th>Action</th>
                                        </tr>
                                </thead>
                                <tbody>
                                    <?php $query=mysqli_query($con,"select * from tblfonts");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>
                                        <tr>
                                            <td><?php echo htmlentities($cnt);?></td>
                                            <td><?php echo htmlentities($row['FontName']);?></td>
                                            <td><?php echo htmlentities($row['FontURL']);?></td>
<?php 
if ($row['website']==1) { ?>
 <td><a href="site-fonts.php?id=<?php echo $row['id']?>&action=activated" class="btn btn-success" onClick="return confirm('Are you sure you want to activate this font?')">Enabled</a> </td>
<?php } else { ?>
 <td><a href="site-fonts.php?id=<?php echo $row['id']?>&action=activated" class="btn btn-danger" onClick="return confirm('Are you sure you want to activate this font?')">Activate</a></td>
<?php } ?>
                        
                                         <td>
                                         <a href="edit-fonts.php?id=<?php echo $row['id']?>" class="btn  btn-icon btn-primary"><i class="feather icon-edit"></i></a>
                                         <a href="site-fonts.php?id=<?php echo $row['id']?>&del=delete" class="btn  btn-icon btn-danger" onClick="return confirm('Are you sure you want to delete?')"><i class="feather icon-delete"></i></a></td>
                                         </tr>
                                        <?php $cnt=$cnt+1; }  ?>
                              
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
                           
                        </div>
                   
                    </div>
                </div>
          
            </div>
            <!-- [ form-element ] end -->
        </div>
        <!-- [ Main Content ] end -->

    </div>
</section>


    <!-- Required Js -->
    <script src="assets/js/vendor-all.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <script src="assets/js/pcoded.min.js"></script>




</body>

</html>
<?php } ?>