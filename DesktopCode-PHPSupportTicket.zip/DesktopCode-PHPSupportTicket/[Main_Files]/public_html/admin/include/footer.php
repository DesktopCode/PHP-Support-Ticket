	<div class="footer">
		<div class="container">
			 

			<b class="copyright">Copyright &copy; 2025 Desktop Code. </b> All rights reserved.
		</div>
	</div>