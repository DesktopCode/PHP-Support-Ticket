<?php
session_start();
error_reporting(0);
include("include/config.php");
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
if(isset($_POST['submit']))
{
$email=$_POST['emailid'];
$password=md5($_POST['inputuserpwd']);
$query=mysqli_query($con,"SELECT id,fullName FROM users WHERE userEmail='$email' and password='$password'");
$num=mysqli_fetch_array($query);
//If Login Suceesfull
if($num>0)
{
$_SESSION['login']=$_POST['email'];
$_SESSION['id']=$num['id'];
$_SESSION['username']=$num['name'];
echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
}
//If Login Failed
else{
    echo "<script>alert('Invalid login details');</script>";
    echo "<script type='text/javascript'> document.location ='index.php'; </script>";
exit();
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- basic -->
   
   <!-- site metas -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <title><?php echo $row1['SiteTitle'];?></title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
  
   <!-- bootstrap css -->
   <link rel="stylesheet" type="text/css" href="../admin/assets/css/bootstrap.min.css">
   <!-- style css -->
<link rel="stylesheet" href="../admin/assets/css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="../admin/assets/css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <!-- fonts -->
   <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,700&display=swap" rel="stylesheet">
   <!-- owl stylesheets -->
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesoeet" href="css/owl.theme.default.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
      media="screen">
 <!-- Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
<style>
html *
{
font-family:<?php echo $rowfont['FontName'];?>;
}
</style>
</head>

<body>
      <!--header section start -->
   <div class="header_section">
      <div class="container-fluid ">
         <div class="row">
            <div class="col-sm-2 col-6">
            </div>
            <div class="col-sm-8 col-6">
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                     aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                  </button><font size="3">
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav">
                        <li class="nav-item">
                           <a class="nav-link" href="../index.php">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../admin/index.php">Admin</a>
                        </li>
                        <li class="nav-item active">
                           <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="registration.php">User Regsitration</a>
                        </li>
                       
                        
                     </ul>
                  </div>
</font>
               </nav>
            </div>
         
         </div>
      </div>
      <!-- banner section start -->
   <!-- [ auth-signin ] start -->
<div class="auth-wrapper">
	<div class="auth-content text-center">
		<h4><span style="color:#000;"> User Login</span></h4>
<hr />
		<div class="card borderless"  style="border: 1px solid black;">
			<div class="row align-items-center ">
				<div class="col-md-12">
					<form method="post">
						
					<div class="card-body">
<div class="col-lg-12">
<?php if($smsg){ ?>
<div class="alert alert-success alert-dismissible" role="alert">
<center><strong><?php echo htmlentities($smsg);?></strong></center>
</div>
<?php } ?>
</div>

<div class="col-lg-12">
<?php if($fmsg){ ?>
<div class="alert alert-danger alert-dismissible" role="alert">
<div id="btnwrap"><strong><?php echo htmlentities($fmsg);?></strong></div>
</div>
<?php } ?>
</div>
						
						<hr>
						<div class="form-group mb-3">
							
							<input type="email" name="emailid" id="emailid" style="border:1px solid black;border-radius:5px;" class="form-control" onBlur="emailAvailability()" required placeholder="Enter Email">
						</div>
						<div class="form-group mb-4">
							
							<input type="password" name="inputuserpwd" class="form-control" style="border:1px solid black;border-radius:5px;" required placeholder="Enter Password">
						</div>
						
						<button class="btn btn-block btn-primary mb-4"  type="submit" name="submit" style="border:1px solid black;border-radius:5px;color:black;"><font size="4"> Signin</font></button>
						<hr>
						<p class="mb-2 text-muted"><font size="3">Forgot password? </font><a href="forgot-password.php" class="f-w-400"><font size="3"> Reset Here</font></a></p>

								<div class="registration">
		                <font size="3">Don't have an account yet?</font><br/><br/>
		                <a href="registration.php" class="btn btn-primary mb-2" style="border:1px solid black;border-radius:5px;color:black;"> 
		                   <font size="3"> Create an account</font>
		                </a>
		            </div>
		          
					</div></form>
		
		                <i class="fa fa-home" aria-hidden="true"><a class="" href="../index.php">
		                    <font size="4"> Back Home</font>
		                </a></i>
		            
				</div>
			</div>
		</div>
	</div>
</div>
  
  
   <!-- footer section end -->
   <!-- copyright section start -->
   <div class="copyright_section">
      <div class="container">
         <br><br><center><p class="copyright_text"><font size="2">Copyright © 2025 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></font></p></center>
      </div>
   </div>
   <!-- copyright section end -->
   <!-- Javascript files-->
   <script src="js/jquery.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <script src="js/plugin.js"></script>
   <!-- sidebar -->
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
   <!-- javascript -->
   <script src="js/owl.carousel.js"></script>
   <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>