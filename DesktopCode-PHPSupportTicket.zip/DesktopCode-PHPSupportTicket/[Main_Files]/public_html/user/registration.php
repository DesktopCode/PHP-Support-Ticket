<?php
session_start();
include('include/config.php');

$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);


$response = null;
if(isset($_POST) & !empty($_POST)){

	                   if($response == null){
		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$verification_key = md5($username);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = md5($_POST['password']);
		$passwordagain = md5($_POST['passwordagain']);
		if($password == $passwordagain){
		$fmsg = "";
			
    $stmt2 = $con->prepare("SELECT userEmail FROM users WHERE userEmail=?");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $result = $stmt2->get_result();
    $stmt2->close();
    $count2 = $result->num_rows;

    $stmt = $con->prepare("SELECT fullName FROM users WHERE fullName=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    $count = $result->num_rows;

    if ($count == 0 AND $count2 == 0) {
			
			$sql = "INSERT INTO `users` (fullName, userEmail, password, status) VALUES ('$username', '$email', '$password', '1')";
			$result = mysqli_query($connection, $sql);
			if($result){
				$smsg = "User Registered Succesfully!";


			}else{
				$fmsg = "Failed To Register User!";
			}
		}else{
			$fmsg = "Email and/or Username Already Exist!";
		}
	}
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <title><?php echo $row1['SiteTitle'];?></title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="stylesheet" href="../admin/assets/css/style.css">
	 <!-- Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
<style>
html *
{
font-family:<?php echo $rowfont['FontName'];?>;
}
</style>
</head>
  <!--header section start -->
   <div class="header_section">
      <div class="container-fluid ">
         <div class="row">
            <div class="col-sm-2 col-6">
            </div>
            <div class="col-sm-8 col-6">
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                     aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                  </button><font size="3">
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav">
                        <li class="nav-item">
                           <a class="nav-link" href="../index.php">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../admin/index.php">Admin</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item active">
                           <a class="nav-link" href="registration.php">User Regsitration</a>
                        </li>
                       
                        
                     </ul>
                  </div>
</font>
               </nav>
            </div>
         
         </div>
      </div>
      <!-- banner section start -->
<!-- [ auth-signin ] start -->
<div class="auth-wrapper">
	<div class="auth-content text-center">
				<h4><span style="color:#000;"> User Registration</span></h4>
				<hr />
		<div class="card borderless"  style="border: 1px solid black;">
			<div class="row align-items-center ">
				<div class="col-md-12">
				
						
					

<?php if($smsg){ ?>
<div class="alert alert-success alert-dismissible" role="alert">
<center><strong><?php echo htmlentities($smsg);?></strong></center>
</div>
<?php } ?>



<?php if($fmsg){ ?>
<div class="alert alert-danger alert-dismissible" role="alert">
<div id="btnwrap"><strong><?php echo htmlentities($fmsg);?></strong></div>
</div>
<?php } ?>

<div class="card-body">
				 <form class="form-signin" method="POST">
        <div><br>
        <input type="text" name="username" id="username" class="form-control" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Enter Username" required>
        <br><br>
        <input type="email" name="email" id="inputEmail" class="form-control" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Enter Email Address" required>
        <br><br>
        <input type="password" name="password" id="inputPassword" class="form-control" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Enter Password" required>
        <br><br><input type="password" name="passwordagain" id="inputPassword" class="form-control" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Enter Password Again" required>
<br><br><div class="btnwrap"><button  class="btn btn-primary" type="submit" style="border:1px solid black;border-radius:5px;color:black;"><font size="3"> Register</font></button></div><br><br>
      </form>
					 <i class="fa fa-home" aria-hidden="true"><a class="" href="../index.php">
		                   <font size="4">  Back Home</font>
		                </a></i>
		</div>
	</div>
</div></div></div></div></div>
<!-- [ auth-signin ] end -->
<div class="copyright_section">
      <div class="container">
         <br><br><center><p class="copyright_text"><font size="2">Copyright © 2025 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></font></p></center>
      </div>
   </div>
<!-- Required Js -->
<script src="../admin/assets/js/vendor-all.min.js"></script>
<script src="../admin/assets/js/plugins/bootstrap.min.js"></script>



</body>

</html>
