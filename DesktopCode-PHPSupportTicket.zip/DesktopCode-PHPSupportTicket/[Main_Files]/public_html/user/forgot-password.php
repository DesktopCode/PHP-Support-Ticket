<?php
session_start();
include('include/config.php');
$username = $_SESSION['username'];
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$querycc=mysqli_query($con,"select * from tblmail WHERE Is_Active='1'");
$rowcc=mysqli_fetch_array($querycc);
$rowwebsite = $rowcc['website'];
$rowsubject = $rowcc['subject'];
$rowfromm = $rowcc['fromm'];
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);

$message="";
$valid='true';
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $email_reg=mysqli_real_escape_string($con,$_POST['email']);
    $details=mysqli_query($con,"SELECT userEmail FROM users WHERE userEmail='$email_reg'");
    if (mysqli_num_rows($details)>0) { //if the given email is in database, ie. registered
        $message_success=" Please check your email inbox or spam folder and follow the steps";
        //generating the random key
        $key=md5(time()+123456789% rand(4000, 55000000));
$sql_insert=mysqli_query($con,"INSERT INTO forget_password(email,temp_key) VALUES('$email_reg','$key')");
        //sending email about update
        $to      = $email_reg;
        $subject = $rowsubject;
        $msg = "Please copy the link and paste in your browser address bar". "\r\n" .$rowwebsite."/forgot_password_reset.php?key=".$key."&email=".$email_reg;
        $headers = "From: $rowfromm";
        mail($to, $subject, $msg, $headers);
    }
    else{
        $message="Sorry! no account associated with this email";
    }
}

?>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <title><?php echo $row1['SiteTitle'];?></title>
   <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
   <meta name="description" content="<?php echo $row1['Description'];?>">
   <!-- bootstrap css -->
   <link rel="stylesheet" type="text/css" href="../admin/assets/css/bootstrap.min.css">
   <!-- style css -->
<link rel="stylesheet" href="../admin/assets/css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="../admin/assets/css/responsive.css">
	<script type="text/javascript">
function valid()
{
if(document.passwordrecovery.newpassword.value!= document.passwordrecovery.confirmpassword.value)
{
alert("New Password and Confirm Password Field do not match  !!");
document.passwordrecovery.confirmpassword.focus();
return false;
}
return true;
}
</script>
 <!-- Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
<style>
html *
{
font-family:<?php echo $rowfont['FontName'];?>;
}
</style>
</head>
  <!--header section start -->
   <div class="header_section">
      <div class="container-fluid ">
         <div class="row">
            <div class="col-sm-2 col-6">
            </div>
            <div class="col-sm-8 col-6">
               <nav class="navbar navbar-expand-lg navbar-light bg-light">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                     aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                  </button><font size="3">
                  <div class="collapse navbar-collapse" id="navbarNav">
                     <ul class="navbar-nav">
                        <li class="nav-item active">
                           <a class="nav-link" href="../index.php">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="index.php">Admin</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../user/index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="../user/registration.php">User Regsitration</a>
                        </li>
                       
                        
                     </ul>
                  </div>
</font>
               </nav>
            </div>
         
         </div>
      </div>
      <!-- banner section start -->
<!-- [ auth-signin ] start -->
<div class="auth-wrapper">
	<div class="auth-content text-center">
		<h4><span style="color:#000;"> Reset Password</span></h4>
	<hr />
		<div class="card borderless"  style="border: 1px solid black;">
			<div class="row align-items-center ">
				<div class="col-md-12">
					<div class="card-body">
	   <div class="container">
            <div class="row">
               <div class="col-lg-12">
<center>
        
          <form role="form" method="POST">
                   <div class="input-group">
              <input  class="form-control" id="email" name="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" style="border:1px solid black;border-radius:5px;color:black;" placeholder="Enter Email" >
            
            <?php if (isset($error)) {
                      echo"<div class='alert alert-danger' role='alert'>
                      <span class='sr-only'>Error:</span>".$error."</div>";
                 } ?>
            <?php if ($message<>"") {
                      echo"<div class='alert alert-danger' role='alert'>
                      <span class='sr-only'>Error:</span>".$message."</div>";
                } ?>
            <?php if (isset($message_success)) {
                      echo"<div class='alert alert-success' role='alert'>
                      <span class='sr-only'></span>".$message_success."</div>";
                  } ?>
              <br><button type="submit" class="btn btn-primary pull-right" name="submit" style="font-size:16px;display: block; width: 100%;border:1px solid black;border-radius:5px;color:black;margin-top:10px;"><font size="4">Send Email</font></button>
    </div>

          </form>
  <center> <br><br><i class="fa fa-home" aria-hidden="true"><a class="" href="../index.php">
		                    <font size="4">Back Home</font>
		                </a></i></center>
        </div>

</div></div></div>
				</div>
			</div>
		</div>
	</div>
</div>
</div></div></div></div></div>
<!-- [ auth-signin ] end -->
<div class="copyright_section">
      <div class="container">
         <br><br><center><p class="copyright_text"><font size="2">Copyright © 2025 All Rights Reserved | DesktopCode | <a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></font></p></center>
      </div>
   </div>
<!-- Required Js -->
<script src="../admin/assets/js/vendor-all.min.js"></script>
<script src="../admin/assets/js/plugins/bootstrap.min.js"></script>

<script src="../admin/assets/js/pcoded.min.js"></script>