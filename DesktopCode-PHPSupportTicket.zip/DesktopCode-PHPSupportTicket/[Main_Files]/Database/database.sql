-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: db5017536463.hosting-data.io
-- Generation Time: Apr 01, 2025 at 01:34 PM
-- Server version: 8.0.36
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs14052164`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `fullname` varchar(259) DEFAULT NULL,
  `mobilenumber` bigint DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `mobilenumber`, `email`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', 8956232356, 'admin@gmail.com', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2023-09-12 05:16:16', '18-10-2016 04:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(2, 'General', 'General', '2023-08-11 10:54:06', '2025-03-25 21:23:01'),
(4, 'Services', 'Services', '2023-09-12 06:26:48', '2025-03-25 20:58:34'),
(5, 'Finance', 'Finance', '2023-09-12 06:27:36', '2025-03-25 20:58:45'),
(6, 'Staff', 'Staff', '2023-09-12 06:33:43', '2025-03-25 20:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `complaintremark`
--

CREATE TABLE `complaintremark` (
  `id` int NOT NULL,
  `complaintNumber` int DEFAULT NULL,
  `UserName` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext,
  `remarkDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaintremark`
--

INSERT INTO `complaintremark` (`id`, `complaintNumber`, `UserName`, `status`, `remark`, `remarkDate`) VALUES
(1, 3, '', 'in process', 'your ticket forward to associated team', '2023-09-15 13:05:38'),
(2, 3, '', 'closed', 'Ticket close in favor of user', '2023-09-15 13:06:31'),
(3, 5, '', 'in process', 'We are reviewing the complaint', '2023-10-01 04:12:48'),
(4, 5, '', 'closed', 'Issue resolved', '2023-10-01 04:13:12'),
(5, 6, '', 'in process', '33333', '2025-03-25 05:07:59'),
(6, 6, '', 'in process', 'cccc', '2025-03-25 05:09:28'),
(7, 6, '', 'in process', 'dss', '2025-03-25 05:39:25'),
(8, 6, 'Demo', 'in process', 'dasdsa', '2025-03-25 06:01:05'),
(9, 6, 'Demo', 'in process', '123213', '2025-03-25 06:08:31'),
(10, 6, 'sdfsd', 'in process', 'dsfs', '2025-03-25 06:10:55'),
(11, 6, 'Demo', 'in process', 'sdddddd', '2025-03-25 07:36:32'),
(12, 6, 'Demo', 'In Progress', 'dssdsdfdsf111', '2025-03-25 07:38:48'),
(13, 6, 'Admin', 'closed', 'sdadsad', '2025-03-25 07:39:40'),
(14, 7, 'Admin', 'In Process', 'dsff', '2025-03-25 07:40:56'),
(15, 7, 'Demo', 'In Process', 'sddasdas', '2025-03-25 07:41:06'),
(16, 7, 'Demo', 'In Process', 'cc', '2025-03-25 07:45:52'),
(17, 7, 'Admin', 'Closed', 'adsd', '2025-03-25 07:48:10'),
(18, 7, 'Admin', 'in process', 'sdad', '2025-03-25 07:49:21'),
(19, 7, 'Admin', 'closed', 'sddfsf', '2025-03-25 07:49:25'),
(20, 8, 'Admin', 'in process', 'sdffd', '2025-03-25 07:50:11'),
(21, 8, 'Demo', 'In Process', 'adasfd', '2025-03-25 07:53:35'),
(22, 8, 'Admin', 'in process', 'sadsad', '2025-03-25 08:06:44'),
(23, 8, 'Demo', 'in process', 'sdfdsf', '2025-03-25 08:07:31'),
(24, 9, 'Admin', 'in process', '123', '2025-03-25 21:03:34'),
(25, 9, 'Demo', 'in process', 'test reply', '2025-03-25 21:03:45'),
(26, 9, 'Admin', 'in process', 'saddasd', '2025-03-27 10:01:57'),
(27, 9, 'Admin', 'in process', 'fdsfds', '2025-03-27 10:03:25'),
(28, 9, 'Admin', 'in process', 'dfs', '2025-03-27 10:11:34'),
(29, 9, 'Admin', 'in process', 'dxv', '2025-03-27 10:19:04'),
(30, 9, 'Admin', 'in process', 'dfggd', '2025-03-27 10:21:17'),
(31, 9, 'Admin', 'in process', 'zdzxfg', '2025-03-27 10:24:54'),
(32, 9, 'Admin', 'in process', 'dsfdsfdsf', '2025-03-27 10:25:27'),
(33, 9, 'Admin', 'in process', 'dfsg', '2025-03-27 10:26:56'),
(34, 9, 'Admin', 'in process', 'sdadsaf', '2025-03-27 10:30:38'),
(35, 9, 'Admin', 'in process', 'asdsad', '2025-03-27 10:31:13'),
(36, 9, 'Admin', 'in process', 'dsfdsdfsdg', '2025-03-27 10:32:22'),
(37, 10, 'Admin', 'in process', 'fsdg', '2025-04-01 01:25:32');

-- --------------------------------------------------------

--
-- Table structure for table `complaintreply`
--

CREATE TABLE `complaintreply` (
  `id` int NOT NULL,
  `complaintNumber` int DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reply` mediumtext,
  `replyDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forget_password`
--

CREATE TABLE `forget_password` (
  `id` int NOT NULL,
  `email` varchar(200) NOT NULL,
  `temp_key` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int NOT NULL,
  `stateName` varchar(255) DEFAULT NULL,
  `stateDescription` tinytext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `stateName`, `stateDescription`, `postingDate`, `updationDate`) VALUES
(3, 'Uttar Pradesh', 'Uttar Pradesh-UP', '2023-09-28 16:56:56', '2023-10-01 10:30:30'),
(4, 'Punjab', 'Punjab-PB', '2023-09-28 16:56:56', '2023-10-01 10:30:33'),
(5, 'Haryana', 'Haryana-HR', '2023-09-28 16:56:56', '2023-10-01 10:30:36'),
(6, 'Delhi', 'Delhi-DL', '2023-09-28 16:56:56', '2023-10-01 10:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int NOT NULL,
  `categoryid` int DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(1, 1, 'Online Shopping', '2023-03-28 07:11:07', '2023-09-14 07:10:13'),
(2, 1, 'E-wllaet', '2023-08-28 07:11:20', '2023-09-14 07:10:00'),
(3, 2, 'other', '2023-09-14 07:06:44', '2023-09-14 07:09:47'),
(4, 2, 'ABC', '2023-09-12 11:40:13', '2023-09-12 11:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomplaints`
--

CREATE TABLE `tblcomplaints` (
  `complaintNumber` int NOT NULL,
  `userId` int DEFAULT NULL,
  `category` int DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `complaintType` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `noc` varchar(255) DEFAULT NULL,
  `complaintDetails` mediumtext,
  `complaintFile` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomplaints`
--

INSERT INTO `tblcomplaints` (`complaintNumber`, `userId`, `category`, `subcategory`, `complaintType`, `state`, `noc`, `complaintDetails`, `complaintFile`, `regDate`, `status`, `lastUpdationDate`) VALUES
(6, 7, 2, 'other', 'General Query', 'Punjab', '123', '321', '80c6465f639c0427b408b6231fdac3cd.png', '2025-03-25 05:07:37', 'closed', '2025-03-25 07:39:40'),
(7, 7, 2, 'other', 'General Query', 'Punjab', '111', '11111', '611d9742630e8ebceeb7b250f92549a5.png', '2025-03-25 07:40:38', 'closed', '2025-03-25 07:49:25'),
(8, 7, 1, 'Online Shopping', ' Complaint', 'Uttar Pradesh', 'sadsad', 'sadas', '80c6465f639c0427b408b6231fdac3cd.png', '2025-03-25 07:49:52', 'in process', '2025-03-25 08:06:44'),
(9, 7, 2, 'other', 'General Query', 'Uttar Pradesh', '222', '333', 'd41d8cd98f00b204e9800998ecf8427e', '2025-03-25 15:30:10', 'in process', '2025-03-25 21:03:34'),
(10, 7, 2, 'ABC', 'General Query', 'Uttar Pradesh', 'aaa', 'aaaa', 'd41d8cd98f00b204e9800998ecf8427e', '2025-03-25 18:59:41', 'in process', '2025-04-01 01:25:32'),
(11, 7, 2, '', 'Complaint', '', '1111', '2222', 'd41d8cd98f00b204e9800998ecf8427e', '2025-03-25 19:09:35', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblfaq`
--

CREATE TABLE `tblfaq` (
  `id` int NOT NULL,
  `Question` longtext,
  `Answer` longtext,
  `Is_Active` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfaq`
--

INSERT INTO `tblfaq` (`id`, `Question`, `Answer`, `Is_Active`) VALUES
(1, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(2, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(3, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(4, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(5, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(6, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(7, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1),
(11, 'Quam neque suspendisse augue nulla fames gravida?', 'Mattis lacinia amet condimentum lacus eu condimentum vel non ridiculus. Tempor dictumst nibh at proin senectus sit, pretium vel morbi.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblfonts`
--

CREATE TABLE `tblfonts` (
  `id` int NOT NULL,
  `FontName` varchar(200) DEFAULT NULL,
  `FontURL` mediumtext,
  `Description` mediumtext,
  `website` int DEFAULT NULL,
  `admin` int DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfonts`
--

INSERT INTO `tblfonts` (`id`, `FontName`, `FontURL`, `Description`, `website`, `admin`, `Is_Active`) VALUES
(1, 'Roboto', '<link href=\"https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap\" rel=\"stylesheet\">', '.roboto-regular ', 0, 0, 0),
(10, 'Teko', '<link href=\"https://fonts.googleapis.com/css2?family=Teko:wght@300..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(11, 'Titillium Web', '<link href=\"https://fonts.googleapis.com/css2?family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&display=swap\" rel=\"stylesheet\">', '--', 0, 0, 0),
(12, 'Montserrat', '<link href=\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(13, 'Spectral SC', '<link href=\"https://fonts.googleapis.com/css2?family=Spectral+SC:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(14, 'Istok Web', '<link href=\"https://fonts.googleapis.com/css2?family=Istok+Web:ital,wght@0,400;0,700;1,400;1,700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(15, 'Smooch Sans', '<link href=\"https://fonts.googleapis.com/css2?family=Smooch+Sans:wght@100..900&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(17, 'Comfortaa', '<link href=\"https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(18, 'Oxanium', '<link href=\"https://fonts.googleapis.com/css2?family=Oxanium:wght@200..800&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(19, 'Josefin Sans', '<link href=\"https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap\" rel=\"stylesheet\">', '---', 0, 0, 0),
(20, 'Play', '<link href=\"https://fonts.googleapis.com/css2?family=Play:wght@400;700&display=swap\" rel=\"stylesheet\">', '----', 0, 0, 0),
(21, 'Poppins', '<link href=\"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap\" rel=\"stylesheet\">', '--', 0, 0, 0),
(23, 'Yanone Kaffeesatz', '<link href=\"https://fonts.googleapis.com/css2?family=Mate+SC&family=Yanone+Kaffeesatz:wght@200..700&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0),
(24, 'Bai Jamjuree', '<link href=\"https://fonts.googleapis.com/css2?family=Bai+Jamjuree:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap\" rel=\"stylesheet\">', 'Bai Jamjuree', 1, 1, 1),
(25, 'Exo', '<link href=\"https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0),
(26, 'Jura', '<link href=\"https://fonts.googleapis.com/css2?family=Jura:wght@300..700&display=swap\" rel=\"stylesheet\">', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblissue`
--

CREATE TABLE `tblissue` (
  `id` int NOT NULL,
  `issueid` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissue`
--

INSERT INTO `tblissue` (`id`, `issueid`, `creationDate`, `updationDate`) VALUES
(1, 'General Query', '2023-03-28 05:11:07', '2025-04-01 02:14:03'),
(2, 'Complaint', '2023-09-12 09:40:13', '2025-03-25 18:57:34'),
(9, 'Request', '2025-03-25 23:52:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblmail`
--

CREATE TABLE `tblmail` (
  `id` int NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `fromm` varchar(255) DEFAULT NULL,
  `Is_Active` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmail`
--

INSERT INTO `tblmail` (`id`, `website`, `subject`, `fromm`, `Is_Active`) VALUES
(1, 'https://www.desktopcode.com', 'Password Reset', 'noreply@desktopcode.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsettings`
--

CREATE TABLE `tblsettings` (
  `id` int NOT NULL,
  `SiteTitle` longtext,
  `MetaTags` longtext,
  `Description` longtext,
  `ClanName` varchar(255) NOT NULL,
  `ForumUrl` mediumtext,
  `ClanLogo` varchar(255) DEFAULT NULL,
  `SiteLogo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsettings`
--

INSERT INTO `tblsettings` (`id`, `SiteTitle`, `MetaTags`, `Description`, `ClanName`, `ForumUrl`, `ClanLogo`, `SiteLogo`, `favicon`) VALUES
(1, 'PHP Support Ticket', 'keywords,here,meta,tags,gaming,clan,website,template,desktopcode,code,admin,', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'Support Ticket', '', 'f50c73d00fda2bd6d78ce4082e70f008.png', 'a35c1acb820023f25d48991846c6b50e.png', 'f50c73d00fda2bd6d78ce4082e70f008.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactNo` bigint DEFAULT NULL,
  `address` tinytext,
  `State` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `pincode` int DEFAULT NULL,
  `userImage` varchar(255) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL,
  `status` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `userEmail`, `password`, `contactNo`, `address`, `State`, `country`, `pincode`, `userImage`, `regDate`, `updationDate`, `status`) VALUES
(7, 'Demo', 'admin@desktopcode.com', 'f0258b6685684c113bad94d91b8fa02a', 1234567890, NULL, NULL, NULL, NULL, '80c6465f639c0427b408b6231fdac3cd.png', '2025-03-25 05:05:47', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaintremark`
--
ALTER TABLE `complaintremark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaintreply`
--
ALTER TABLE `complaintreply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forget_password`
--
ALTER TABLE `forget_password`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  ADD PRIMARY KEY (`complaintNumber`);

--
-- Indexes for table `tblfaq`
--
ALTER TABLE `tblfaq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblfonts`
--
ALTER TABLE `tblfonts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissue`
--
ALTER TABLE `tblissue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmail`
--
ALTER TABLE `tblmail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsettings`
--
ALTER TABLE `tblsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `complaintremark`
--
ALTER TABLE `complaintremark`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `complaintreply`
--
ALTER TABLE `complaintreply`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `forget_password`
--
ALTER TABLE `forget_password`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  MODIFY `complaintNumber` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblfaq`
--
ALTER TABLE `tblfaq`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblfonts`
--
ALTER TABLE `tblfonts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblissue`
--
ALTER TABLE `tblissue`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblmail`
--
ALTER TABLE `tblmail`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
